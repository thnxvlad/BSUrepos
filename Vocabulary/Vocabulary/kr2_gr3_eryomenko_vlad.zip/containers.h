#pragma once
#ifndef CONTAINERS_H
#define CONTAINERS_H

namespace containers
{
	template<typename T>
	class BiDirectionalListOnArray;
}

#endif 
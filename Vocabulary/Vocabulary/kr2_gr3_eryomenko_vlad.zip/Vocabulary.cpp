#include "Vocabulary.h"

WordCard* Vocabulary::convert_string_to_word_card(string str)
{
	return new WordCard(str);
}
